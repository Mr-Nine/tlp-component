
'''
@Project:
@Team:
@Author: jerome.du
@LastEditors: jerome.du
@Date: 2019-12-12 20:44:56
@LastEditTime: 2020-03-13 20:11:08
@Description:
'''

import uuid
import json
import datetime

from TLPLibrary.core import *
from TLPLibrary.error import *
from TLPLibrary.entity import *

from TLPLibrary.service import BusinessService

class ImportLabelService(BusinessService):

    def __init__(self):
        super(ImportLabelService, self).__init__()

    def importManyImageLabel(self, run_parameter, images):
        '''
        @description:批量导入
        @param {run_parameter}:程序运行的入口参数对象
        @para {images}:
        @return:
        '''

        try:
            self._checkRunParameter(run_parameter)
            self._checkImagesParameter(run_parameter, images)

            project_info = self._findProjectInfo(run_parameter)
            project_id = project_info["id"]
            table_index = str(project_info['index'])

            now = datetime.datetime.today()
            image_table_name = self._config.project_image_table_name + table_index

            # 导入的批次版本号，先通过时间做一个标识
            version = self._getImportBatchVersion()

            for image in images:
                # TODO: 有什么办法可以不是每次都查一次呢？
                # TODO: 如果给定的图片并不存在于项目中，是否应该不抛出异常而是跳过，那是不是应该有写日志的办法？
                imageInfo = self._findProjectImageInfo(image_table_name, image.path)
                image.id = imageInfo['id']

                # 数据库中已存在的元数据模板信息
                database_mate_label_template_map = self._buildLabelTemplateDatabaseMap(project_id, LabelType.MATE)
                # 数据库中已存在的区域模板信息
                database_region_label_template_map = self._buildLabelTemplateDatabaseMap(project_id, LabelType.REGION)

                # 数据组织变量声明
                merged_mate_label_template_list = []
                merged_region_label_template_list = []
                insert_mate_label_template_values = []
                update_mate_label_template_values = []
                insert_region_label_template_values = []
                update_region_label_template_values = []
                mate_label_values = []
                region_values = []
                region_label_values = []

                # 提取这张图片的元数据标签模板信息
                self._mergeLabelTemplate(image.mate_labels, database_mate_label_template_map, merged_mate_label_template_list)

                # 提取需要创建或更新的元数据标签模板信息
                print("A")
                print(merged_mate_label_template_list)
                print("B")
                for mate_label_template in merged_mate_label_template_list:
                    template_label_attribute = json.dumps(mate_label_template["attribute"])
                    if "id" in mate_label_template and mate_label_template["id"]:
                        # 处理要更新的元数据标签模板数据
                        update_mate_label_template_values.append((template_label_attribute, now, mate_label_template['id']))
                    else:
                        # 处理要新增的元数据标签模板数据
                        background_color = mate_label_template["backgroundColor"]
                        if not background_color:
                            background_color = self._generateRandomColors()
                        mate_label_template['id'] = str(uuid.uuid4())
                        insert_mate_label_template_values.append((mate_label_template['id'], run_parameter.project_id, mate_label_template['name'], LabelType.MATE, TaggingType.IMPORT, 1, background_color, 0, 0, 0, 0, template_label_attribute, run_parameter.user_id, now, now))

                # 提取并组织图片要写入的元数据标签
                for mate_label in image.mate_labels:
                    label_template_id = self._getLabelTemplateIdByTemplateName(mate_label.name, merged_mate_label_template_list, database_mate_label_template_map)
                    if label_template_id is None:
                        raise NotFoundException("运行异常，没有找到标签所属的模板信息")
                    mate_label_id = str(uuid.uuid4())
                    mate_label_attribute = mate_label.generateAttributeJson()
                    mate_label_values.append((mate_label_id, image.id, label_template_id, TaggingType.AUTO, '1', mate_label_attribute, run_parameter.user_id, now, now))

                # 提取这张图片的区域标签模板信息
                for region in image.regions:
                    self._mergeLabelTemplate(region.labels, database_region_label_template_map, merged_region_label_template_list)

                # 提取需要创建或更新的区域标签模板信息
                for region_label_template in merged_region_label_template_list:
                    template_label_attribute = json.dumps(region_label_template["attribute"])
                    if "id" in region_label_template and region_label_template["id"]:
                        # 处理要更新的区域数据标签模板数据
                        update_region_label_template_values.append((template_label_attribute, now, region_label_template["id"]))
                    else:
                        # 处理要新增的区域数据标签模板数据
                        background_color = region_label_template["backgroundColor"]
                        if not background_color:
                            background_color = self._generateRandomColors()
                        region_label_template['id'] = str(uuid.uuid4())
                        insert_region_label_template_values.append((region_label_template['id'], run_parameter.project_id, region_label_template['name'], LabelType.REGION, TaggingType.IMPORT, 1, background_color, 0, 0, 0, 0, template_label_attribute, run_parameter.user_id, now, now))


                # 处理Region、RegionLabel和他的模板信息
                index = 0
                for region in image.regions:
                    region_id = str(uuid.uuid4())
                    # 提取需要写入的区域信息
                    region_values.append((region_id, image.id, index, region.shape, region.getShapeDataJson(), run_parameter.user_id, now, now))
                    index += 1

                    for region_label in region.labels:
                        background_color = self._getLabelBackgroundColor(region_label)
                        region_label_attribute = region_label.generateAttributeJson()
                        label_template_id = self._getLabelTemplateIdByTemplateName(region_label.name, merged_region_label_template_list, database_region_label_template_map) #self._findLabelTemplateId(region_label_template_map, region_label.name)
                        if label_template_id is None:
                            raise NotFoundException("运行异常，没有找到标签所属的模板信息")
                        region_label_id = str(uuid.uuid4())
                        region_label_values.append((region_label_id, image.id, region_id, label_template_id, TaggingType.AUTO, '1.0', region_label_attribute, run_parameter.user_id, now, now))

                # 写入新增的标签模板
                if insert_mate_label_template_values or insert_region_label_template_values:
                    print("insert new mate and region label template...")
                    print(insert_mate_label_template_values)
                    print(insert_region_label_template_values)
                    insert_label_template_sql = """insert into """ + self._config.project_label_template_table_name + """ (`id`, `projectId`, `name`, `type`, `source`, `heat`, `backgroundColor`, `enabled`, `required`, `defaulted`, `reviewed`, `attribute`, `creatorId`, `createTime`, `updateTime`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                    insert_result = self._mysql.close_transaction_insert_many(insert_label_template_sql, insert_mate_label_template_values + insert_region_label_template_values)
                    print("insert " + str(insert_result) + " entries.")

                # 更新已经存在的有变更的标签模板
                if update_mate_label_template_values or update_region_label_template_values:
                    print("update mate and region label template.")
                    print(update_mate_label_template_values)
                    update_result = 0
                    update_label_template_sql = """update """ + self._config.project_label_template_table_name + """ set `attribute` = %s, `updateTime` = %s where `id` = %s"""
                    if update_mate_label_template_values:
                        for u_m_l_t_v in update_mate_label_template_values:
                            update_result += self._mysql.update(sql=update_label_template_sql, parameter=u_m_l_t_v, auto_commit=False)

                    print(update_region_label_template_values)
                    if update_region_label_template_values:
                        for u_r_l_t_v in update_region_label_template_values:
                            update_result += self._mysql.update(sql=update_label_template_sql, parameter=(u_m_l_t_v, ), auto_commit=False)

                    # update_result = self._mysql.update(sql=update_label_template_sql, parameter=update_mate_label_template_values + update_region_label_template_values, auto_commit=False)
                    print("update " + str(update_result) + " entries.")

                # 处理并写入MateLabel信息，关联LabelTemplate和图片
                if mate_label_values:
                    print("insert new image mate label info.")
                    print(mate_label_values)
                    insert_mate_label_sql = """insert into """ + self._config.project_mate_label_table_name + table_index + """ (`id`, `imageId`, `labelId`, `type`, `version`, `attribute`, `userId`, `createTime`, `updateTime`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) """
                    insert_result = self._mysql.close_transaction_insert_many(insert_mate_label_sql, mate_label_values)
                    print("insert " + str(insert_result) + " entries.")

                # 写入新增的region信息并关联图片
                if region_values:
                    print("insert new imagee region info.")
                    print(region_values)
                    insert_region_sql = """insert into """ + self._config.project_image_region_table_name + table_index + """ (`id`, `imageId`, `index`, `shape`, `shapeData`, `userId`, `createTime`, `updateTime`) values (%s, %s, %s, %s, %s, %s, %s, %s)"""
                    insert_result = self._mysql.close_transaction_insert_many(insert_region_sql, region_values)
                    print("insert " + str(insert_result) + " entries.")

                # 写入region的label信息，关联模板和图片
                if region_label_values:
                    print("insert new image region lable info.")
                    print(region_label_values)
                    insert_region_lable_sql = """insert into """ + self._config.project_image_region_label_table_name + table_index + """ (`id`, `imageId`, `regionId`, `labelId`, `type`, `version`, `attribute`, `userId`, `createTime`, `updateTime`) values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
                    insert_result = self._mysql.close_transaction_insert_many(insert_region_lable_sql, region_label_values)
                    print("insert " + str(insert_result) + " entries.")

                self._mysql.end()

                print("import image lable info success.")
        finally:
            self._mysql.destory(is_end=False)

    def importOneImageLabel(self, run_parameter, image):
        '''
        @description: 导入单张图片的标签信息的方法
        @param {type}
        @return:
        '''
        if not isinstance(image, Image):
            raise ClassCastException("请指定要导入标签的图片对象")

        self.importManyImageLabel(run_parameter=run_parameter, images=(image))


    def _buildLabelTemplateDatabaseMap(self, project_id, leabel_type):
        mate_label_template_map = {}
        database_result = self._loadProjectLabelsByDatabase(project_id, leabel_type)

        if database_result is None:
            return mate_label_template_map

        for database_label in database_result:
            label_dict = Utils.transform_database_result_2_dict(database_label)
            if 'attribute' in label_dict and label_dict['attribute'] is not None and len(label_dict['attribute']) > 1:
                label_dict['attribute'] = json.loads(label_dict['attribute'])
            mate_label_template_map[label_dict['name']] = label_dict

        return mate_label_template_map
