# -- coding: utf-8 --
'''
@Project:
@Team:
@Author: jerome.du
@LastEditors: jerome.du
@Date: 2019-12-12 13:52:40
@LastEditTime: 2020-03-20 17:52:49
@Description:
'''

import json

from TLPLibrary.core import GenericEntity
from TLPLibrary.error import *
from TLPLibrary.entity import ValueType, LabelType

class Label(GenericEntity):

    def __init__(self, name, background_color=None):
        super(Label, self).__init__()
        self.name = name
        self.id = None
        self.background_color = background_color
        self.attributes = {}
        self.__confidence = None


    def addAttribute(self, key, value_type, value):
        if not ValueType.check_type(value_type):
            value_type = ValueType.TEXT
        self.attributes[key] = {"type":value_type, "value":value}


    def removeAttribute(self, key):
        del self.attributes[key]


    def hasAttribute(self):
        return True if self.attributes else False


    def generateAttributeData(self):
        attribute_data = {}
        for key in self.attributes:
            attribute_data[key] = self.attributes[key]["value"]
            # attributeMap = {key:self.attributes[key]["value"]}
            # attribute_data.append(attributeMap)

        # if self.__confidence is not None:
        #     attribute_data["confidence"] = self.__confidence

        return attribute_data


    def generateAttributeJson(self):
        return json.dumps(self.generateAttributeData())


    def generateLabelTemplateData(self):
        template_data = []
        for key in self.attributes:
            template = {}
            template['key'] = key
            template['name'] = key
            template['type'] = self.attributes[key]["type"]
            template['default'] = ''
            template_data.append(template)

        return template_data


    def generateLabelTemplateJson(self):
        return json.dumps(self.generateLabelTemplateData())


    def setLabelConfidence(self, confidence):
        '''
        设置标签的置信度
        Args:
            param (float): confidence 标签的置信度是多少
        '''
        if not isinstance(confidence, float):
            raise DataCastException("confidence cast error.")

        self.__confidence = confidence


    def getLabelConfidence(self):
        return self.__confidence


class MetaLabel(Label):

    def __init__(self, name):
        super(MetaLabel, self).__init__(name)
        self.type = LabelType.META


class RegionLabel(Label):

    def __init__(self, name):
        super(RegionLabel, self).__init__(name)
        self.region_id = None
        self.type = LabelType.REGION
