# -- coding: utf-8 --
'''
@Project:
@Team:
@Author: jerome.du
@LastEditors: jerome.du
@Date: 2019-12-12 16:46:29
@LastEditTime: 2019-12-12 16:47:07
@Description:
'''

class LabelType():
    MATE = "MATE"
    REGION = "REGION"