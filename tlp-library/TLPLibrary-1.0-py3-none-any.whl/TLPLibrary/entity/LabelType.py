# -- coding: utf-8 --
'''
@Project:
@Team:
@Author: jerome.du
@LastEditors: jerome.du
@Date: 2019-12-12 16:46:29
@LastEditTime: 2020-03-16 14:52:02
@Description:
'''

class LabelType():
    META = "META"
    REGION = "REGION"