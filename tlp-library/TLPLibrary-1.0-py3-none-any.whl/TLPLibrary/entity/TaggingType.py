# -- coding: utf-8 --
'''
@Project:
@Team:
@Author: jerome.du
@LastEditors: jerome.du
@Date: 2019-12-11 19:01:35
@LastEditTime: 2019-12-11 21:01:29
@Description:
'''

class TaggingType():

    MANUAL = "MANUAL"
    AUTO = "AUTO"
    IMPORT="IMPORT"