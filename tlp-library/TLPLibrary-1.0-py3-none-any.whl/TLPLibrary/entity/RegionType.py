# -- coding: utf-8 --
'''
@Project:
@Team:
@Author: jerome.du
@LastEditors: jerome.du
@Date: 2019-12-11 18:53:53
@LastEditTime: 2019-12-12 11:00:31
@Description:
'''

class RegionType(object):

    RECTANGLE = "RECTANGLE"
    POLYGON = "POLYGON"